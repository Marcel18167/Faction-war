# Server
Gun Server plugin

Add more info in here later like wherer to do what n stuff
