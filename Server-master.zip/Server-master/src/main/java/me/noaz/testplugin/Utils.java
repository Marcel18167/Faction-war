/* Not used for now - may be used if this is a better solution
package me.noaz.testplugin;

import me.noaz.testplugin.gamemodes.Game;

public class Information {
    private static Game currentGame = null;

    //This should probably be made better..
    public static void newGame(Game game) {
        currentGame = game;
    }

    public static Game getGame() {
    return currentGame;
    }
}*/
/*
Sounds:

ghast death: Nuke

Zombie attack iron door: Maybe shoot with python?
Also entity.ghast.shoot

Skeleton hurt

iron golem hit / wither shoot both for snipers

block.note_block.snare

entity.item.break


Spider death: Enemy has charlie
Skeleton death: Captured Charlie
Silverfish kill: Kill confirmed
Pig Death: We captured alpha
Irongolem death: We captured Bravo
Ghast Death: Tactical Nuke Incomming
Enderman death: Enemy has Alpha
Creeper Death: Enemy has Alpha
Blaze Death: Rock n roll at start of game

Cave 1-13 (all same but different): Spawn sounds

levelup: Weird rock sound (I guess when u lvl up)



 */